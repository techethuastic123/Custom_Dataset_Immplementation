# YOLO-NAS
## Implementation on Custom Dataset | Fall Detection Using YOLO-NAS

### Check this video for better understanding: https://www.youtube.com/watch?v=pgf9bPuEsFo

![output](https://user-images.githubusercontent.com/60029146/236439781-f583c7f1-716c-4024-9ab4-cb8e2be28d2b.jpg)
![image](https://user-images.githubusercontent.com/60029146/236439878-70e94664-8a6f-4cc9-bc47-f1d13b233087.png)




